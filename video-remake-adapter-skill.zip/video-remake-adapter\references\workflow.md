# Video Remake Workflow

## Output Folder Pattern

Use this structure for full projects:

```text
project-name/
  00_brief/
  01_source_analysis/
  02_remake_design/
  03_assets/
  04_prompts/
  05_editing/
  06_qc/
  07_outputs/
```

## Source Analysis Table

Use one row per shot when the video is short. Use one row per beat when the video is long or only described by the user.

Required columns:

- `id`: stable shot or beat id, such as `S001`.
- `source_time`: timestamp range, such as `00:03-00:06`.
- `source_event`: plain description of what happens.
- `story_function`: why this moment exists.
- `character_function`: role in the moment, such as "skeptical customer", not the original identity.
- `scene_function`: what the setting contributes, such as "public pressure", not the original place.
- `prop_function`: what the object does, such as "proof", "temptation", "obstacle".
- `camera_intent`: reveal, pressure, intimacy, confusion, spectacle, proof, transition.
- `emotion`: tension, curiosity, relief, shock, envy, warmth, urgency.
- `audio_function`: silence, punch sound, riser, comedic sting, testimonial clarity.
- `must_not_copy`: concrete source details that must be avoided.

## Replacement Matrix

For each source element, create a replacement with a different category or visual identity.

Required columns:

- `source_element`
- `source_role`
- `replace_with`
- `new_visual_signature`
- `what_to_preserve`
- `what_to_avoid`
- `prompt_token`

Example:

```csv
source_element,source_role,replace_with,new_visual_signature,what_to_preserve,what_to_avoid,prompt_token
luxury office,power/status,night market repair stall,neon tarps, cramped benches, warm steam,status contrast,glass wall office layout,scene_repair_stall
```

## Remake Shot List

Required columns:

- `shot_id`
- `duration_sec`
- `new_beat`
- `new_character_tags`
- `new_scene_tag`
- `new_prop_tags`
- `action`
- `camera`
- `lighting_color`
- `dialogue_or_caption`
- `audio`
- `video_prompt`
- `negative_prompt`
- `qc_notes`

## Handoff Sequence

1. Write `remake-brief.md`.
2. Fill source analysis.
3. Fill replacement matrix.
4. Write character, scene, and prop bibles.
5. Write new script.
6. Build shot list.
7. Build video prompts.
8. Build audio and editing plan.
9. Run QC.
10. Summarize what changed and what remains as the abstract source structure.

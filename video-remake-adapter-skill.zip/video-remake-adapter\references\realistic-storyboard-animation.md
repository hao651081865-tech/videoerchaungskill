# Realistic Storyboard Animation Prompt

Use this reference after creating the source reverse prompt. The goal is to transform the reverse-prompt content into a cinematic, realistic, horizontal storyboard animation prompt.

## Fixed Assembly Rule

Place the reverse-prompt content immediately after `画面内容：`.

```text
生成真人写实风格，根据以下内容自我理解后生成相应的分镜动画，合理的构建分镜，合理的动作，合理的运镜，合理的环境渲染，发散你的想象力。不要字幕，电影级分镜理解，合理的空镜头运用，横屏模式： 时间：白天 地点：客厅内 画面内容：[source reverse-prompt content]
```

## Output Format

### Complete Storyboard Animation Prompt

Write one complete prompt that starts with the fixed assembly text above. Keep the `画面内容：` section at the end of the fixed prefix, followed by the reverse-prompt content.

### Shot Expansion

After the complete prompt, provide a shot-by-shot expansion when the user wants a full production package:

- `镜头编号`
- `时长`
- `画面内容`
- `人物/主体`
- `动作`
- `场景环境`
- `光影`
- `运镜`
- `空镜头/插入镜头`
- `情绪节奏`
- `画质参数`

## Default Creative Rules

- Generate live-action realism, not animation or comic style, unless the user overrides it.
- Use horizontal framing by default: 16:9.
- Use daytime and living room interior when the user's fixed template includes them.
- Do not include subtitles, captions, text overlays, logo overlays, or UI elements.
- Use cinematic storyboard logic: establishing shot, subject entrance, action progression, detail insert, reaction, spatial reset, and closing beat.
- Add empty shots naturally: sunlight over sofa, curtain movement, coffee table detail, dust in light, hallway silence, room tone.
- Make actions physically plausible and continuous.
- Make camera movement purposeful: push-in for discovery, pull-back for isolation, pan for reveal, dolly/slide for relationship shifts, low angle for pressure, high angle for vulnerability.
- Render the environment with believable materials, ambient sound potential, and tactile details.

## Quality Defaults

Use these defaults unless the user provides different values:

- Resolution: 4K.
- Frame rate: 24 fps for cinematic motion, 25 fps if targeting China broadcast-style delivery.
- Aspect ratio: 16:9 horizontal.
- Lens feel: 35mm or 50mm cinematic lens, shallow-to-medium depth of field.
- Motion: natural motion blur, stable cinematic movement.
- Lighting: realistic daylight through windows, soft bounce light, controlled contrast.
- Effects: subtle dust particles, natural reflections, no flashy VFX unless story requires it.

## QC

Before finalizing:

- Confirm the reverse-prompt content appears after `画面内容：`.
- Confirm no subtitles are requested.
- Confirm the prompt says真人写实风格.
- Confirm horizontal mode is explicit.
- Confirm time and location are included when provided.
- Confirm every shot includes subject, action, scene, lighting, camera, style, and quality details.

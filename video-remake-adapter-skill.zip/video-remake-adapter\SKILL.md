---
name: video-remake-adapter
description: End-to-end video reverse-prompt, asset locking, storyboard prompt, API video generation, and remake/adaptation workflow. Use when the user provides or references a video and asks to reverse engineer prompts, infer video prompts, analyze subject/action/scene/lighting/camera/style/quality, remake or adapt a video, replace characters/scenes/props/dialogue, create new image assets first, confirm assets before video generation, or produce organized AI short-video deliverables.
---

# Video Remake Adapter

Use this skill to turn a reference video into a new production package and final generated video clips. Preserve only abstract structure: story function, pacing, emotional beats, reversal mechanism, shot intent, and information order. Replace concrete creative elements: people, looks, clothes, scene design, props, wording, visible text, and distinctive compositions.

Never pass off a locally rendered slideshow, storyboard, or stitched placeholder as a model-generated final video. Final video clips must come from the project-approved video generation method unless the user explicitly asks for a local preview.

## Fixed Gate Sequence

Always follow these gates in order:

1. **Reverse prompt first.** Analyze the provided video and write a complete reverse-prompt result. Include subject, action, scene, lighting, camera, style, quality, dialogue/voice-over, sound, UI/text, and source technical specs.
2. **Wait for reverse-prompt confirmation.** Do not generate assets before the user confirms the reverse prompt.
3. **Generate assets after confirmation.** Create character, scene, and prop assets from the confirmed reverse prompt and the user's asset templates when provided.
4. **Wait for asset confirmation.** Show generated assets and stop. Do not submit video tasks before the user confirms the assets.
5. **Write storyboard/video prompts.** Use confirmed assets and the source's abstract beat rhythm. Do not create storyboard images unless the user explicitly asks for them.
6. **Ask for video model and API options.** Ask which model to use unless the current project already has an explicit user-confirmed model. Confirm any size/ratio compromise when the provider does not support the source ratio.
7. **Generate through the real video API/tool.** Save task IDs, create/status responses, model, duration, size, reference count, prompts, and downloaded files.
8. **Deliver organized files.** Put assets, videos, and project records in the standard project folder structure. Avoid duplicates.

If the user sends a single word such as "确认", advance exactly one gate: reverse prompt -> assets, or assets -> storyboard/video prompt, or model/size confirmation -> API generation.

## Reverse Prompt Requirements

Use the user's current reverse-prompt template when provided. If no template is provided, use `references/reverse-prompt.md`.

The reverse prompt must:

- Be based on the source video, not on a guessed story.
- Include visible dialogue, subtitles, VO, OS, and on-screen text as accurately as possible.
- Clearly separate "source video has subtitles/text" from "final remake should not show subtitles/text" when the user requests no text.
- State source technical specs when obtainable: duration, ratio, resolution, fps, audio presence.
- Stop for user confirmation before assets.

If exact dialogue cannot be verified, say so and mark the lines for user confirmation. Do not invent certainty.

## Remake Rules

For the new video:

- Match the source style unless the user changes it. If the source is anime, produce anime-style assets/video. If the source is AI realistic live-action, produce AI realistic live-action assets/video.
- Replace every recognizable concrete element: character design, wardrobe, location, props, wording, visible text, and distinctive scene dressing.
- Keep only the abstract mechanism: conflict setup, reversal, rhythm, emotional progression, marketing beat, or joke structure.
- Dialogue is allowed unless the user says no dialogue. "No subtitles/text" means no visible words, not silent characters.
- If the user requests no background music, prompts must still allow dialogue and useful environment/action sound unless the user requests mute video.

Use `references/remake-rules.md` for originality boundaries when needed.

## Asset Stage

Use `references/asset-template-prompts.md` when the user provides or expects character/scene/prop templates, four-view, three-view, or six-view assets.

Asset rules:

- Generate each asset as its own file. Do not combine different assets into one contact sheet unless the user explicitly asks for a review sheet.
- A multi-view sheet for a single asset is allowed when requested: one character four-view image, one scene four-view image, one prop six-view image.
- Main recurring characters need character assets; main locations need scene assets; continuity-critical props need prop assets.
- Scene assets must contain no people.
- Asset prompts must include "no subtitles, no text, no logo, no watermark."
- Show assets to the user and wait for confirmation before writing final video prompts or submitting video tasks.

## Storyboard And Video Prompt Stage

Use `references/storyboard-template-workflow.md`.

Prompt rules:

- Use confirmed asset names/IDs and only the new world, not the source's concrete visuals.
- Split long videos into provider-supported clip lengths.
- If the user says not to stitch, deliver independent clips with clear names.
- If the user wants one final film, ask before stitching generated clips; only stitch after all clips come from the real video API/tool.
- Keep prompts under provider limits and include only relevant reference images per clip.
- Include no visible subtitles, no captions, no readable text, no logos, no watermarks, and no background music when requested.

## API Boundary

Use `references/customer-api-workflow.md` when the current project uses image/video APIs.

Never store API keys, service endpoints, bucket names, fixed model-choice rules, user source folders, or output roots in this reusable skill. Treat them as per-project configuration from the user, local files, or environment variables.

Before creating video tasks:

- Confirm the exact video model with the user unless already confirmed in the current project.
- Confirm size/ratio when the source ratio is unsupported by the API.
- Upload approved assets only to a user-approved/public hosting method.
- Save task records so interrupted runs can resume without duplicate submissions.
- If a model, duration, size, or reference count fails, report the non-secret error and ask for fallback unless the user already gave an explicit fallback rule for the current project.

Local processing after API generation is allowed only for delivery hygiene, such as renaming, moving, verifying, transcoding fps/size, or stitching when approved. Record that the visual content came from the API.

## Delivery Folder Organization

Use one project folder per drama, episode set, or short film. Do not scatter clips or assets directly under a shared delivery root.

Recommended localized structure:

```text
[项目名]/
  人物资产/
  场景资产/
  道具资产/
  视频/
    第1集/
  项目资料/
```

Rules:

- Put character images only in `人物资产`.
- Put scene images only in `场景资产`.
- Put prop images only in `道具资产`.
- Put generated clips in `视频`; if there are episodes, create `视频/第N集/`.
- Put reverse prompts, asset prompts, storyboard prompts, API task records, summaries, rejected versions, and temporary records in `项目资料`.
- Do not duplicate assets or videos.
- If the user asks for a final-only folder, put only final videos there and keep assets/project files elsewhere inside the same project folder.

## Resource Guide

- `references/reverse-prompt.md`: default source reverse-prompt structure.
- `references/asset-template-prompts.md`: character, scene, prop, four-view, three-view, and six-view asset prompt rules.
- `references/storyboard-template-workflow.md`: storyboard/video prompt structure, timing, dialogue, and clip rules.
- `references/customer-api-workflow.md`: project API workflow, public media URLs, task creation, polling, downloading, and recovery.
- `references/quality-checklist.md`: final review checklist.
- `references/remake-rules.md`: originality and replacement rules.
- `references/workflow.md`: source deconstruction tables and production package schema.
- `scripts/create_remake_project.py`: optional helper for blank project packages.

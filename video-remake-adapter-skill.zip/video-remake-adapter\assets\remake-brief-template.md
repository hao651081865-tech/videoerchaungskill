# Remake Brief

## Source

- Source video:
- Target duration:
- Platform/aspect ratio:
- Language:

## New Concept

- New title:
- Genre/style:
- Audience:
- Core hook:
- Emotional arc:

## Originality Boundary

- Preserve:
- Replace:
- Must avoid:

## Deliverables

- Source analysis:
- Replacement matrix:
- Character bible:
- Scene bible:
- Prop bible:
- Script:
- Shot list:
- Video prompts:
- Audio/edit plan:
- QC:

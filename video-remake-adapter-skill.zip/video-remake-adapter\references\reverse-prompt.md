# Source Video Reverse Prompt

Use this reference when the user asks to infer or reverse-engineer a complete prompt from a video.

## Required Output

Produce two layers:

1. A concise complete prompt that can be pasted into a video generation tool.
2. A structured breakdown that proves the prompt covers subject, action, scene, lighting, camera, style, and quality.

If the source video is unavailable, write "Based on the user's description only" before the result.

## Complete Prompt Template

```text
[Subject]. [Action]. [Scene and atmosphere]. [Lighting]. [Camera movement and framing]. [Visual style and color]. [Quality/render settings].
```

## Structured Breakdown

### Subject

Describe the core people, objects, props, wardrobe, expressions, physical features, materials, scale, texture, and visible identifiers. Avoid guessing brand names or identities when they are not visible.

### Action

Describe exact dynamic behavior: who moves, what changes, object interaction, gesture, speed, timing, continuity, facial expression shifts, and any repeated motion.

### Scene

Describe environment, atmosphere, location type, time of day, weather, background layers, spatial layout, crowd density, signage only if visible, and emotional setting.

### Lighting

Describe light source, direction, strength, softness, color temperature, contrast, shadows, rim light, reflections, practical lights, and exposure.

### Camera

Describe shot size, angle, movement, lens feel, depth of field, focus behavior, stabilization, speed changes, and duration. Use terms such as push-in, pull-back, pan, tilt, truck, dolly, orbit, handheld, high angle, low angle, close-up, medium shot, wide shot, overhead.

### Style

Describe visual style, genre, color grading, texture, mood, art direction, realism level, medium, and palette.

### Quality

Describe resolution, frame rate, aspect ratio, sharpness, motion blur, grain/noise, VFX, particles, subtitles, render quality, and export target.

## Per-Shot Table Columns

Use these columns when the video has multiple shots:

- `shot_id`
- `timestamp`
- `subject`
- `action`
- `scene`
- `lighting`
- `camera`
- `style`
- `quality`
- `complete_prompt`

## Phrasing Rules

- Use concrete visual language instead of vague praise.
- Separate observed facts from inferred production settings.
- Keep the final prompt generation-ready.
- Do not include copyrighted titles, real person identity, or brand names unless the user explicitly needs analytical labeling.
- When using the reverse prompt for remake work, feed only abstract functions and technical language into the new prompt; do not copy unique source visuals.
